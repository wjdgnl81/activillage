package com.activillage.manager.sales.vo;

import com.activillage.common.vo.CommonVO;

public class SalesVO extends CommonVO{
	public String sales="";
	public String s_cname="";
	public String s_joinday="";
	public String s_email="";
	
	public String getSales() {
		return sales;
	}
	public void setSales(String sales) {
		this.sales = sales;
	}
	public String getS_cname() {
		return s_cname;
	}
	public void setS_cname(String s_cname) {
		this.s_cname = s_cname;
	}
	public String getS_joinday() {
		return s_joinday;
	}
	public void setS_joinday(String s_joinday) {
		this.s_joinday = s_joinday;
	}
	public String getS_email() {
		return s_email;
	}
	public void setS_email(String s_email) {
		this.s_email = s_email;
	}
	
	
}

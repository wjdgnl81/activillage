package com.activillage.manager.info.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.user.answer.service.AnswerService;
import com.activillage.user.answer.vo.AnswerVO;
import com.activillage.user.inquiry.service.InquiryService;
import com.activillage.user.inquiry.vo.InquiryVO;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping("/inquiry")
public class inquiryController {

	@Autowired
	private InquiryService inquiryService;

	@Autowired
	private AnswerService answerService;

	// 글 삭제 구현
	@ResponseBody
	@RequestMapping(value = "/inquiryDelete", method = RequestMethod.POST)
	public String inquiryDelete(@ModelAttribute InquiryVO ivo) {
		// 아래 변수에는 입력 성공에 대한 상태값을 담습니다. (1 or 0)
		int result = 0;
		String value = "";
		result = inquiryService.inquiryDelete(ivo.getS_q_no());
		if (result == 1) {
			value = "Y";
		} else {
			value = "N";
		}
		return value;
	}

	// 답변 삭제 구현
	@ResponseBody
	@RequestMapping(value = "/inquiryAnswerDelete", method = RequestMethod.POST)
	public String inquiryAnswerDelete(@ModelAttribute AnswerVO avo) {
		// 아레 변수에는 입력 성공에 대한 상태값을 담습니다. (1 or 0)
		int result = 0;
		String value = "";
		result = answerService.inquiryAnswerDelete(avo.getS_a_no());
		if (result == 1) {
			value = "Y";
		} else {
			value = "N";
		}
		return value;
	}

	// 글 목록 구현
	@RequestMapping(value = "/inquiryList", method = RequestMethod.GET)
	public String InquiryList(@ModelAttribute InquiryVO ivo, AnswerVO avo, Model model, HttpSession session) {
		
		if (session.getAttribute("loginType").equals("user")) {
			ivo.setU_email(session.getAttribute("u_email").toString());
			ivo.setKeyword("user");
		}
		
		// 페이지 세팅
		Paging.setPage(ivo);

		// 전체 레코드수 구현
		int total = inquiryService.inquiryListCnt(ivo);
		log.info("total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(ivo.getPage()) - 1) * Util.nvl(ivo.getPageSize());
		log.info("count = " + count);

		

		List<InquiryVO> inquiryList = inquiryService.inquiryList(ivo);

		for (int i = 0; i < inquiryList.size(); i++) {
			if (answerService.answerExist(inquiryList.get(i).getS_q_no()) != null) {
				inquiryList.get(i).setSearch("O");
			} else {
				inquiryList.get(i).setSearch("X");
			}
		}

		model.addAttribute("inquiryList", inquiryList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("inquiry_data", ivo);

		String result = "";
		if (session.getAttribute("loginType").equals("manager")) {
			result = "inquiryM/inquiryList";
		} else {
			result = "inquiry/inquiryList";
		}

		return result;
	}

	// 문의등록창 (취소버튼)
	@RequestMapping(value = "/inquiryCancle", method = RequestMethod.GET)
	public String inquiryCancle(@ModelAttribute InquiryVO ivo, Model model, HttpSession session) {
		List<InquiryVO> inquiryList = inquiryService.inquiryList(ivo);
		model.addAttribute("inquiryList", inquiryList);
		model.addAttribute("data", ivo);
		
		String result = "";
		if (session.getAttribute("loginType").equals("manager")) {
			result = "inquiryM/inquiryList";
		} else {
			result = "inquiry/inquiryList";
		}

		return result;
	}

	// 1:1문의(등록) 창으로 이동
	@RequestMapping(value = "/inquiryRegi", method = RequestMethod.GET)
	public String inquiryRegi(HttpSession session) {
		String result = "";
		if (session.getAttribute("loginType").equals("manager")) {
			result = "inquiryM/inquiryRegi";
		} else {
			result = "inquiry/inquiryRegi";
		}

		return result;
	}

	// 1:1문의 등록버튼 클릭하여 DB에 글 등록
	@RequestMapping(value = "/inquiryRegiBtn", method = RequestMethod.POST)
	public String inquiryRegiBtn(@ModelAttribute InquiryVO ivo, Model model, HttpServletRequest request,
			HttpSession session) throws IllegalStateException, IOException {
		int result = 0;
		String url = "";
		result = inquiryService.inquiryRegi(ivo);
		if (result == 1) {
			url = "/inquiry/inquiryList.do";
		} else {
			model.addAttribute("code", 1);
			url = "/inquiry/inquiryRegi.do";
		}
		return "redirect:" + url; // return 맵핑명으로 받을때 redirect 를 쓴다
	}

	// 1:1문의 답변등록버튼 클릭하여 DB에 글 등록
	@RequestMapping(value = "/inquiryAnswerRegi", method = RequestMethod.POST)
	public String inquiryAnswerRegi(@ModelAttribute AnswerVO avo, Model model, HttpServletRequest request)
			throws IllegalStateException, IOException {
		System.out.println("inquiryAnswerRegi 호출");
		int result = 0;
		String url = "";
		result = answerService.inquiryAnswerRegi(avo);
		if (result == 1) {
			url = "/inquiry/inquiryList.do";
		} else {
			model.addAttribute("code", 1);
			url = "/inquiry/inquiryList.do";
		}
		return "redirect:" + url; // return 맵핑명으로 받을때 redirect 를 쓴다
	}

	// 1:1문의 리스트에서 제목클릭시 상세보기 구현
	@RequestMapping(value = "/inquiryDetail", method = RequestMethod.GET)
	public String inquiryDetail(@ModelAttribute InquiryVO ivo, AnswerVO avo, Model model,HttpSession session) {

		InquiryVO detail = new InquiryVO();
		AnswerVO detail1 = new AnswerVO();

		detail = inquiryService.inquiryDetail(ivo);
		detail1 = answerService.answerDetail(avo);

		model.addAttribute("detail", detail);
		model.addAttribute("detail1", detail1);
		
		String result = "";
		if (session.getAttribute("loginType").equals("manager")) {
			result = "inquiryM/inquiryDetail";
		} else {
			result = "inquiry/inquiryDetail";
		}

		return result;
	}
}
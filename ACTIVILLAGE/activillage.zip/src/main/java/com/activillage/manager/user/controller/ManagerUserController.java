package com.activillage.manager.user.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.activillage.common.excel.ListExcelView;
import com.activillage.common.graph.ChartMake;
import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.manager.user.service.ManagerUserService;
import com.activillage.user.book.vo.BookVO;
import com.activillage.user.join.vo.UserJoinVO;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping(value = "/manager")
public class ManagerUserController {

	@Autowired
	private ManagerUserService managerUserService;

	@RequestMapping(value = "/main/userManage", method = RequestMethod.GET)
	public String userManage(@ModelAttribute UserJoinVO uvo, Model model, HttpServletRequest request) {
		log.info("manager userManage 호출 성공");

		// 페이지 세팅
		Paging.setPage(uvo);

		// 전체레코드 수 구현
		int total = managerUserService.userListCnt(uvo);
		log.info("total=" + total);

		// 글번호 재설정
		int count = total - (Util.nvl(uvo.getPage()) - 1) * Util.nvl(uvo.getPageSize());
		log.info("count = " + count);

		List<UserJoinVO> userList = managerUserService.userList(uvo);
		for (int i = 0; i < userList.size(); i++) {
			System.out.println(userList.get(i).getU_birth().substring(1, 7));
			userList.get(i).setU_birth(userList.get(i).getU_birth().substring(1, 7));
			System.out.println(userList.get(i).getU_birth());
		}
		model.addAttribute("userList", userList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("u_data", uvo);

		return "manager/main/userManage";
	}

	@RequestMapping(value = "/managerBookList", method = RequestMethod.GET)
	public String userBookList(@ModelAttribute BookVO bvo, Model model, HttpServletRequest request) {
		log.info("manager managerBookList 호출 성공");

		// 페이지 세팅
		Paging.setPage(bvo);

		// 전체레코드 수 구현
		int total = managerUserService.managerBookListCnt(bvo);
		log.info("total=" + total);

		// 글번호 재설정
		int count = total - (Util.nvl(bvo.getPage()) - 1) * Util.nvl(bvo.getPageSize());
		log.info("count = " + count);

		List<BookVO> managerBookList = managerUserService.managerBookList(bvo);

		model.addAttribute("managerBookList", managerBookList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("b_data", bvo);

		return "manager/main/managerBookList";
	}

	@RequestMapping(value = "/userChart", method = RequestMethod.GET)
	public String userChart(@ModelAttribute UserJoinVO uvo, Model model, HttpServletRequest request,
			HttpSession session) {
		// 연령데이터
		Map<String, Integer> userAgeList = managerUserService.userAgeList();
		ChartMake.userPieChart(request, userAgeList, session);

		return "manager/main/userChart";
	}

	@RequestMapping(value = "/userChartDown", method = RequestMethod.GET)
	public void userChartDown(ModelMap model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		String dFile = "userPieChart.jpg";
		String upDir = session.getAttribute("upChartDir").toString();
		String path = upDir + File.separator + dFile;

		File file = new File(path);
		String userAgent = request.getHeader("User-Agent");
		boolean ie = userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("rv:11") > -1;
		String fileName = null;

		if (ie) {
			fileName = URLEncoder.encode(file.getName(), "utf-8");
		} else {
			fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1");
		}

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");

		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream bis = new BufferedInputStream(fis);
		ServletOutputStream so = response.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(so);

		byte[] data = new byte[2048];
		int input = 0;
		while ((input = bis.read(data)) != -1) {
			bos.write(data, 0, input);
			bos.flush();
		}

		if (bos != null)
			bos.close();
		if (bis != null)
			bis.close();
		if (so != null)
			so.close();
		if (fis != null)
			fis.close();
	}

	// 강제탈퇴
	@RequestMapping(value = "/userWithdrawal")
	public ModelAndView userWithdrawal(@ModelAttribute UserJoinVO uvo, HttpServletRequest request, HttpSession session)
			throws IOException {
		log.info("userWithdrawal 호출 성공");

		// 아래 변수에는 입력 성공에 대한 상태값 담습니다.(1 or 0)
		int result = 0;
		ModelAndView mav = new ModelAndView();
		result = managerUserService.userWithdrawal(uvo.getU_email());
		System.err.println("controller result:" + result);
		if (result == 1) {
			session.setAttribute("withUserCode", 1);
			mav.setViewName("redirect:/manager/main/userManage.do");
		} else {
			session.setAttribute("withUserCode", 2);
			mav.setViewName("redirect:/manager/main/userManage.do");
		}
		return mav;
	}

	// 예약현황 엑셀저장
	@RequestMapping(value = "/userBookExcel", method = RequestMethod.GET)
	public ModelAndView boardExcel(@ModelAttribute BookVO bvo) {
		log.info("userBookExcel 호출 성공");

		List<BookVO> bookList = managerUserService.managerBookList(bvo);

		ModelAndView mv = new ModelAndView(new ListExcelView());
		mv.addObject("list", bookList);
		mv.addObject("template", "managerBook.xlsx");
		mv.addObject("file_name", "managerBook");

		return mv;
	}
}

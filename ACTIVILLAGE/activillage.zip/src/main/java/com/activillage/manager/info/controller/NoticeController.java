package com.activillage.manager.info.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.common.file.FileUploadUtil;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.notice.service.NoticeService;
import com.activillage.user.notice.vo.NoticeVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping("/notice")
public class NoticeController {

	@Autowired
	private NoticeService noticeService;

	// 공지사항 리스트
	@RequestMapping(value = "/noticeList", method = RequestMethod.GET)
	public String noticeList(@ModelAttribute NoticeVO nvo, Model model, HttpSession session) {
		log.info("notice List 호출성공");
		List<NoticeVO> noticeList = noticeService.noticeList();
		model.addAttribute("noticeList", noticeList);
		model.addAttribute("data", nvo);
		String result = "";
		if (session.getAttribute("loginType") != null && session.getAttribute("loginType").equals("manager")) {
			result = "noticeM/noticeList";
		} else {
			result = "notice/noticeList";
		}

		return result;
	}

	// 등록하기 페이지로 이동 (공지사항 등록하기 페이지)
	@RequestMapping(value = "/noticeRegi", method = RequestMethod.GET)
	public String noticeRegi(HttpSession session) {
		log.info("notice Regi get 호출 성공");

		String result = "";

		if (session.getAttribute("loginType").equals("manager")) {
			result = "noticeM/noticeRegi";
		} else {
			result = "notice/noticeRegi";
		}
		return result;
	}

	// 등록버튼 클릭하여 DB에 글 등록
	@RequestMapping(value = "/noticeListRegi", method = RequestMethod.POST)
	public String noticeRegiBtn(@ModelAttribute NoticeVO nvo, Model model, HttpServletRequest request,
			HttpSession session) throws IllegalStateException, IOException {
		log.info("noticeListRegi post 호출 성공");
		int result = 0;
		String url = "";

		result = noticeService.noticeRegi(nvo);
		System.out.println("공지등록" + result);
		if (result == 1) {
			url = "/notice/noticeList";
		} else {
			url = "/notice/noticeRegi";
			model.addAttribute("code", 1);
		}
		return "redirect:" + url;
	}

	// 공지사항 수정 창
	@RequestMapping(value = "/noticeModify", method = RequestMethod.GET)
	public String noticeModify(@ModelAttribute NoticeVO nvo, Model model, HttpSession session)
			throws IllegalStateException, IOException {
		log.info("noticeModify get 호출 성공");

		NoticeVO noticeDetail = new NoticeVO();
		noticeDetail = noticeService.noticeDetail(nvo);

		model.addAttribute("noticeDetail", noticeDetail);

		String result = "";

		if (session.getAttribute("loginType").equals("manager")) {
			result = "noticeM/noticeModify";
		} else {
			result = "notice/noticeModify";
		}

		return result;
	}

	// 공지사항 수정 메소드
	@RequestMapping(value = "/noticeUpdate", method = RequestMethod.POST)
	public String noticeUpdate(@ModelAttribute NoticeVO nvo, Model model) throws IllegalStateException, IOException {
		log.info("noticeUpdate get 호출 성공");

		int result = 0;
		String url = "";
		result = noticeService.noticeUpdate(nvo);

		if (result == 1) {
			url = "redirect:/notice/noticeList";
		} else {
			url = "redirect:/notice/noticeModify.do?n_no=" + nvo.getN_no();
		}

		return url;
	}

	// 공지사항 삭제
	@RequestMapping(value = "/noticeDelete.do", method = RequestMethod.POST)
	public String noticeDelete(@ModelAttribute NoticeVO nvo, HttpServletRequest request) throws IOException {
		log.info("noticeDelete 호출 성공");

		int result = 0;
		String url = "";

		result = noticeService.noticeDelete(nvo.getN_no());
		if (result == 1) {
			url = "redirect:/notice/noticeList";
		} else {
			url = "redirect:/notice/noticeList";
		}

		return url;
	}
}

package com.activillage.seller.reservation.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.activillage.seller.reservation.vo.ReservationVO;

public class ReservationDaoImpl implements ReservationDao {
	
	@Autowired
	private SqlSession session;
	
	@Override
	public int sellerReservationCnt(ReservationVO rvo) {
		
		return (Integer) session.selectOne("sellerReservationCnt");
	}

	@Override
	public List<ReservationVO> sellerReservationList(ReservationVO rvo) {
		
		return session.selectList("sellerReservationList", rvo);
	}

}

package com.activillage.seller.goods.vo;

public class PackageVO {

	private int p_no = 0;
	private int g_no = 0;
	private String g_name = ""; //상품명
	private String p_name = ""; //패키지명
	private int p_price = 0;  //패키지 가격
	private int p_amount = 0;  //패키지 수량
	private String g_sday="";  //상품 영업 시작일
	private String g_eday = "";  //상품 영업 종료일
	private String p_sday = "";  //패키지 영업 시작일
	private String p_eday = "";  //패키지 영업 종료일
	
	private String min_price = "";
	
	
	public String getMin_price() {
		return min_price;
	}
	public void setMin_price(String min_price) {
		this.min_price = min_price;
	}
	public int getP_no() {
		return p_no;
	}
	public void setP_no(int p_no) {
		this.p_no = p_no;
	}
	public int getG_no() {
		return g_no;
	}
	public void setG_no(int g_no) {
		this.g_no = g_no;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		this.g_name = g_name;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public int getP_amount() {
		return p_amount;
	}
	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}
	public String getG_sday() {
		return g_sday;
	}
	public void setG_sday(String g_sday) {
		this.g_sday = g_sday;
	}
	public String getG_eday() {
		return g_eday;
	}
	public void setG_eday(String g_eday) {
		this.g_eday = g_eday;
	}
	public String getP_sday() {
		return p_sday;
	}
	public void setP_sday(String p_sday) {
		this.p_sday = p_sday;
	}
	public String getP_eday() {
		return p_eday;
	}
	public void setP_eday(String p_eday) {
		this.p_eday = p_eday;
	}
	
	
	
}

package com.activillage.seller.reservation.dao;

import java.util.List;

import com.activillage.seller.reservation.vo.ReservationVO;

public interface ReservationDao {

	// (종륜) 12월 21일 추가 예약 전체 갯수
	public int sellerReservationCnt(ReservationVO rvo);

	// (종륜) 12월 21일 추가 예약 리스트 구현
	public List<ReservationVO> sellerReservationList(ReservationVO rvo);

}

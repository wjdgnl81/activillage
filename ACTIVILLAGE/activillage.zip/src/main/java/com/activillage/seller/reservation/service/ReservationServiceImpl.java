package com.activillage.seller.reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.seller.reservation.dao.ReservationDao;
import com.activillage.seller.reservation.vo.ReservationVO;

@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	private ReservationDao reservationDao;

	@Override
	public int sellerReservationCnt(ReservationVO rvo) {

		return reservationDao.sellerReservationCnt(rvo);
	}

	@Override
	public List<ReservationVO> sellerReservationList(ReservationVO rvo) {

		List<ReservationVO> sellerReservationList = null;

		sellerReservationList = reservationDao.sellerReservationList(rvo);

		return sellerReservationList;
	}
}

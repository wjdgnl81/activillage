package com.activillage.seller.goods.vo;

import org.springframework.web.multipart.MultipartFile;

import com.activillage.common.vo.CommonVO;

public class GoodsVO extends CommonVO {

	private int g_no = 0;
	private String s_email = ""; // 사업자 email
	private String s_phone = ""; // 사업자 연락처
	private String g_name = ""; // 상품명
	private String g_do = ""; // 지역
	private String g_category = ""; // 카테고리
	private int g_price = 0; // 기본 가격
	private String g_thumb = ""; // 썸네일
	private String g_image1 = ""; // 이미지1
	private String g_image2 = ""; // 이미지2
	private String g_image3 = ""; // 이미지3
	private String g_sday = ""; // 상품 영업 시작일
	private String g_eday = ""; // 상품 영업 종료일
	private String g_intro = ""; // 상품 소개글
	private String g_info = ""; // 주의 사항
	private String g_rday = ""; // 상품 등록일
	private String g_post = ""; // 게시 여부
	private double g_grade = 0; //평점

	// 파일 업로드
	private MultipartFile thumbfile;
	private MultipartFile file1;
	private MultipartFile file2;
	private MultipartFile file3;

	public double getG_grade() {
		return g_grade;
	}

	public void setG_grade(double g_grade) {
		this.g_grade = g_grade;
	}

	public MultipartFile getThumbfile() {
		return thumbfile;
	}

	public void setThumbfile(MultipartFile thumbfile) {
		this.thumbfile = thumbfile;
	}

	public MultipartFile getFile1() {
		return file1;
	}

	public void setFile1(MultipartFile file1) {
		this.file1 = file1;
	}

	public MultipartFile getFile2() {
		return file2;
	}

	public void setFile2(MultipartFile file2) {
		this.file2 = file2;
	}

	public MultipartFile getFile3() {
		return file3;
	}

	public void setFile3(MultipartFile file3) {
		this.file3 = file3;
	}

	public int getG_no() {
		return g_no;
	}

	public void setG_no(int g_no) {
		this.g_no = g_no;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getS_phone() {
		return s_phone;
	}

	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getG_do() {
		return g_do;
	}

	public void setG_do(String g_do) {
		this.g_do = g_do;
	}

	public String getG_category() {
		return g_category;
	}

	public void setG_category(String g_category) {
		this.g_category = g_category;
	}

	public int getG_price() {
		return g_price;
	}

	public void setG_price(int g_price) {
		this.g_price = g_price;
	}

	public String getG_thumb() {
		return g_thumb;
	}

	public void setG_thumb(String g_thumb) {
		this.g_thumb = g_thumb;
	}

	public String getG_image1() {
		return g_image1;
	}

	public void setG_image1(String g_image1) {
		this.g_image1 = g_image1;
	}

	public String getG_image2() {
		return g_image2;
	}

	public void setG_image2(String g_image2) {
		this.g_image2 = g_image2;
	}

	public String getG_image3() {
		return g_image3;
	}

	public void setG_image3(String g_image3) {
		this.g_image3 = g_image3;
	}

	public String getG_sday() {
		return g_sday;
	}

	public void setG_sday(String g_sday) {
		this.g_sday = g_sday;
	}

	public String getG_eday() {
		return g_eday;
	}

	public void setG_eday(String g_eday) {
		this.g_eday = g_eday;
	}

	public String getG_intro() {
		return g_intro;
	}

	public void setG_intro(String g_intro) {
		this.g_intro = g_intro;
	}

	public String getG_info() {
		return g_info;
	}

	public void setG_info(String g_info) {
		this.g_info = g_info;
	}

	public String getG_rday() {
		return g_rday;
	}

	public void setG_rday(String g_rday) {
		this.g_rday = g_rday;
	}

	public String getG_post() {
		return g_post;
	}

	public void setG_post(String g_post) {
		this.g_post = g_post;
	}

}

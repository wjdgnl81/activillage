package com.activillage.seller.goods.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.goodslist.vo.GoodsListVO;

@Repository
public class GoodsDaoImpl implements GoodsDao {

	@Autowired
	private SqlSession session;

	// 상품 리스트
	@Override
	public List<GoodsListVO> goodsList(GoodsListVO gvo) {
		return session.selectList("goodsList", gvo);
	}

	// 상품 등록
	@Override
	public int goodsRegiste(GoodsVO gvo) {
		return session.insert("goodsRegiste", gvo);
	}

	// 상품 상세
	@Override
	public GoodsVO goodsDetail(GoodsVO gvo) {
		return (GoodsVO) session.selectOne("goodsDetail", gvo);
	}

	// 상품 수정
	@Override
	public int goodsUpdate(GoodsVO gvo) {
		return session.update("goodsUpdate", gvo);
	}

	// 상품 삭제
	@Override
	public int goodsDelete(int g_no) {
		return session.delete("goodsDelete", g_no);
	}

	// 상품 게시
	@Override
	public int goodsPostUp(int g_no) {
		return session.update("goodsPostUp", g_no);
	}

	// 상품 내리기
	@Override
	public int goodsPostDown(int g_no) {
		return session.update("goodsPostDown", g_no);
	}

	@Override
	public GoodsVO goodsSelect(String g_name) {
		return (GoodsVO) session.selectOne("goodsSelect", g_name);
	}

	@Override
	public int goodsPriceUpdate(GoodsVO gvo) {
		return session.update("goodsPriceUpdate", gvo);
	}

	// 사업자 탈퇴용 리스트
	@Override
	public List<GoodsVO> goodsPostedList(String s_email) {
		return session.selectList("goodsPostedList", s_email);
	}

	// (종륜) 상품 전체 갯수
	@Override
	public int goodsListCnt(GoodsVO gvo) {

		return (Integer) session.selectOne("goodsListCnt");
	}

	// (종륜) 상품 리스트 구현
	@Override
	public List<GoodsVO> mypageGoodsList(GoodsVO gvo) {

		return session.selectList("mypageGoodsList", gvo);
	}

	@Override
	public List<GoodsListVO> popularList(GoodsListVO gvo) {
		return session.selectList("popularList", gvo);
	}

	@Override
	public int mainGoodsListCnt(GoodsListVO gvo) {
		return (Integer) session.selectOne("mainGoodsListCnt", gvo);
	}
}

package com.activillage.seller.goods.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;

@Repository
public class PackageDaoImpl implements PackageDao {

	@Autowired
	private SqlSession session;
	
	//패키지관리 불러오기
	@Override
	public GoodsVO packageManager(GoodsVO gvo) {
		return (GoodsVO) session.selectOne("packageManager",gvo);
	}

	//패키지 목록
	@Override
	public List<PackageVO> packageList(Integer g_no) {
		return session.selectList("packageList");
	}

	//패키지 등록
	@Override
	public int packageRegiste(PackageVO pvo) {
		return session.insert("packageRegiste",pvo);
	}

	//패키지 삭제
	@Override
	public int packageDelete(int p_no) {
		return session.delete("packageDelete",p_no);
	}

	//최소값 불러오기
	@Override
	public PackageVO packageMinSelect(int g_no) {
		return (PackageVO) session.selectOne("packageMinSelect",g_no);
	}

	@Override
	public PackageVO packageSelect(Integer p_no) {
		return (PackageVO) session.selectOne("packageSelect",p_no);
	}
	
	@Override
	   public int packageGoodsDelete(int g_no) {
	      return session.delete("packageGoodsDelete", g_no);
	   }
}

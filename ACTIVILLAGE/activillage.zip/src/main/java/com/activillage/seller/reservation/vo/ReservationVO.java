package com.activillage.seller.reservation.vo;

import com.activillage.common.vo.CommonVO;

public class ReservationVO extends CommonVO {

	private String b_bday = "";
	private String g_name = "";
	private String p_name = "";
	private int b_tamount = 0;
	private String u_name = "";
	private String u_phone = "";
	private String s_email = "";
	private String b_cday = "";

	public String getB_bday() {
		return b_bday;
	}

	public void setB_bday(String b_bday) {
		this.b_bday = b_bday;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getB_tamount() {
		return b_tamount;
	}

	public void setB_tamount(int b_tamount) {
		this.b_tamount = b_tamount;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_phone() {
		return u_phone;
	}

	public void setU_phone(String u_phone) {
		this.u_phone = u_phone;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getB_cday() {
		return b_cday;
	}

	public void setB_cday(String b_cday) {
		this.b_cday = b_cday;
	}

}

package com.activillage.user.book.service;

import java.util.List;

import com.activillage.user.book.vo.BookVO;

public interface BookService {

	public int cardPay(BookVO bvo);

	public BookVO bookCount(BookVO bvo);

	// 2018-12-21 추가 - 김정휘
	public int bookCheck(String g_name);

	public int bookCheck2(int p_no);

	/* 12.28리뷰관련 */
	public int goReviewWrite(BookVO bvo);

	// 12월 25일 추가하였음 - 고종륜
	public int userReservationCnt(BookVO bvo);

	public List<BookVO> userReservationList(BookVO bvo);

	// 2018-12-26 추가 - 김정휘
	// 예약취소
	public int bookCancle(BookVO bvo);

}

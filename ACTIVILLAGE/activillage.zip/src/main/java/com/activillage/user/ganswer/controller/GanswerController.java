package com.activillage.user.ganswer.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.activillage.user.ganswer.service.GanswerService;
import com.activillage.user.ganswer.vo.GanswerVO;

@Controller
@RequestMapping(value = "/ganswer")
public class GanswerController {

	@Autowired
	GanswerService gAnswerService;

	@ResponseBody
	@RequestMapping(value = "/gAnswerWriteForm.do", method = RequestMethod.POST)
	public String gAnswerWrite(@ModelAttribute GanswerVO avo, HttpSession session) {
		System.out.println("gAnswerWrite 호출 성공");
		int result = 0;
		gAnswerService.gAnswerWrite(avo);
		result = 1;

		return result + "";
	}

	@ResponseBody
	@RequestMapping(value = "/gAnswerDelete.do", method = RequestMethod.POST)
	public String gAnswerDelete(@ModelAttribute GanswerVO avo, HttpSession session) {
		System.out.println("gAnswerDelete 호출 성공");
		int result = 0;
	
		System.out.println(avo.getG_a_no());
		result = gAnswerService.gAnswerDelete(avo.getG_a_no());

		return result + "";
	}

}

package com.activillage.user.inquiry.dao;

import java.util.List;

import com.activillage.user.inquiry.vo.InquiryVO;

public interface InquiryDao{
	public List<InquiryVO> inquiryList(InquiryVO ivo);	//문의사항 목록보기
	public int inquiryRegi(InquiryVO ivo);	//문의사항 등록하기
	public int inquiryDelete(int s_q_no);	//문의사항 삭제하기
	public InquiryVO inquiryDetail(InquiryVO ivo);//문의사항 상세보기
	public int inquiryListCnt(InquiryVO ivo); //페이징
}

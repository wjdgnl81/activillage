package com.activillage.user.mypage.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.manager.seller.service.ManagerSellerService;
import com.activillage.manager.user.service.ManagerUserService;
import com.activillage.seller.goods.service.GoodsService;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.join.service.SellerJoinService;
import com.activillage.seller.join.vo.SellerJoinVO;
import com.activillage.seller.login.service.LoginService;
import com.activillage.seller.reservation.service.ReservationService;
import com.activillage.seller.reservation.vo.ReservationVO;
import com.activillage.seller.sales.service.SellerSalesService;
import com.activillage.seller.sales.vo.SellerSalesVO;
import com.activillage.user.book.service.BookService;
import com.activillage.user.book.vo.BookVO;
import com.activillage.user.join.service.UserJoinService;
import com.activillage.user.join.vo.UserJoinVO;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping(value = "/mypage")
public class UserMypageController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private UserJoinService userjoinService;

	@Autowired
	private ManagerSellerService managerSellerService;

	@Autowired
	private ManagerUserService managerUserService;

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private SellerJoinService sellerjoinService;

	@Autowired
	private ReservationService sellerReservationService;

	@Autowired
	private BookService userReservationService;

	@Autowired
	private SellerSalesService sellerSalesService;

	// 마이페이지 이동
	@RequestMapping(value = "user/myPageMain", method = RequestMethod.GET)
	public String myPage() {

		log.info("myPage 호출성공");
		return "mypage/user/myPageMain";
	}

	// 마이페이지 -> 사용자 정보변경페이지 불러오기
	@RequestMapping(value = "user/modifyInfo", method = RequestMethod.GET)
	public ModelAndView userModifyInfo(HttpSession session) {

		log.info("modifyInfo 페이지 호출 성공");

		// 모델뷰 인스턴스 선언
		ModelAndView mav = new ModelAndView();

		// 로그인에서 설정한 세션값 가져오기
		UserJoinVO login = (UserJoinVO) session.getAttribute("loginSession");

		// 변수명 login에 있는 u_email 세션을 가져와 셀렉트하고 다시 vo 객체 인스턴스에 값 저장
		UserJoinVO vo = userjoinService.userSelect(login.getU_email());
		System.out.println("login.getU_email :" + login.getU_email());
		mav.addObject("user", vo); // "user" 에 vo 저장하고 보냄
		mav.setViewName("mypage/user/modifyInfo"); // 페이지 경로설정
		return mav;
	}

	// 마이페이지 -> 사용자 정보변경페이지 불러오기
	@RequestMapping(value = "user/modifyInfo", method = RequestMethod.POST)
	public ModelAndView userModifyProcess(@ModelAttribute("UserJoinVO") UserJoinVO uvo, HttpSession session) {

		log.info("post 방식에 의한 modifyInfo 페이지 호출 성공");

		// 모델뷰 인스턴스 선언
		ModelAndView mav = new ModelAndView();

		// 로그인에서 설정한 세션값 가져오기
		UserJoinVO login = (UserJoinVO) session.getAttribute("loginSession");

		// 메소드에 들어갈 파라미터 uvo에 세션에서 설정한 u_email을 set함
		uvo.setU_email(login.getU_email());

		// uvo에 있는 u_email을 가져와 셀렉트하고 객체 인스턴스명 vo에 값을 저장
		UserJoinVO vo = userjoinService.userSelect(uvo.getU_email());

		if (userjoinService.userUpdate(uvo)) {
			mav.setViewName("redirect:/mypage/user/myPageMain.do");
			return mav;
		}
		mav.addObject("user", vo); // "user"에 vo 저장하고 보냄
		mav.setViewName("mypage/user/modifyInfo"); // 페이지 경로 설정

		return mav;
	}

	// 마이페이지 -> 사용자 비밀번호변경페이지 불러오기
	@RequestMapping(value = "user/modifyPw", method = RequestMethod.GET)
	public String userModifyPw() {

		log.info("사업자 비밀번호변경페이지 호출 성공");
		return "mypage/user/modifyPw";
	}

	// 마이페이지 -> 사용자 예약확인페이지 불러오기
	@RequestMapping(value = "user/reservationCheck", method = RequestMethod.GET)
	public String reservation(@ModelAttribute BookVO bvo, Model model, HttpSession session) {

		log.info("reservation 페이지 호출 성공");

		String userEmail = (String) session.getAttribute("u_email");
		// 메소드에 들어갈 파라미터 bvo에 세션에서 설정한 u_email을 set함
		bvo.setU_email(userEmail);
		// 페이지 세팅
		Paging.setPage(bvo);

		// 전체 레코드수 구현
		int total = userReservationService.userReservationCnt(bvo);

		log.info("예약 total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(bvo.getPage()) - 1) * Util.nvl(bvo.getPageSize());

		// bookList 변수를 선언하고 bookService 내 bookList메소드 호출하여 변수에 저장
		List<BookVO> reservationCheckList = userReservationService.userReservationList(bvo);

		// 모델에 추가
		model.addAttribute("reservationCheckList", reservationCheckList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", bvo);

		System.out.println("u_email :" + bvo.getU_email());

		return "mypage/user/reservationCheck";
	}

	// 마이페이지 -> 사업자 정보변경페이지 불러오기 12월 14일 통합할때 추가
	@RequestMapping(value = "seller/modifyInfo", method = RequestMethod.GET)
	public ModelAndView sellerModifyInfo(HttpSession session) {

		log.info("modifyInfo 페이지 호출 성공");

		// 모델뷰 인스턴스 선언
		ModelAndView mav = new ModelAndView();

		// 로그인에서 설정한 세션값 가져오기
		SellerJoinVO login = (SellerJoinVO) session.getAttribute("loginSession");

		// 변수명 login에 있는 s_email 세션을 가져와 셀렉트하고 다시 vo 객체 인스턴스에 값 저장
		SellerJoinVO vo = sellerjoinService.sellerSelect(login.getS_email());
		System.out.println("login.getS_email :" + login.getS_email());
		mav.addObject("seller", vo); // "user" 에 vo 저장하고 보냄
		mav.setViewName("mypage/seller/modifyInfo"); // 페이지 경로설정
		return mav;
	}

	// 마이페이지 -> 사업자 정보변경페이지 불러오기 12월 14일 통합할때 추가
	@RequestMapping(value = "seller/modifyInfo", method = RequestMethod.POST)
	public ModelAndView sellerModifyProcess(@ModelAttribute("SellerJoinVO") SellerJoinVO svo, HttpSession session) {

		log.info("post 방식에 의한 modifyInfo 페이지 호출 성공");

		// 모델뷰 인스턴스 선언
		ModelAndView mav = new ModelAndView();

		// 로그인에서 설정한 세션값 가져오기
		SellerJoinVO login = (SellerJoinVO) session.getAttribute("loginSession");

		// 메소드에 들어갈 파라미터 svo에 세션에서 설정한 s_email을 set함
		svo.setS_email(login.getS_email());

		// svo에 있는 s_email을 가져와 셀렉트하고 객체 인스턴스명 vo에 값을 저장
		SellerJoinVO vo = sellerjoinService.sellerSelect(svo.getS_email());

		if (sellerjoinService.sellerUpdate(svo)) {
			mav.setViewName("redirect:/mypage/user/myPageMain.do");
			return mav;
		}
		mav.addObject("seller", vo); // "seller"에 vo 저장하고 보냄
		mav.setViewName("mypage/seller/modifyInfo"); // 페이지 경로 설정

		return mav;
	}

	// 마이페이지 -> 사업자 비밀번호변경페이지 불러오기
	@RequestMapping(value = "seller/modifyPw", method = RequestMethod.GET)
	public String sellerModifyPw() {

		log.info("사업자 비밀번호변경페이지 호출 성공");
		return "mypage/seller/modifyPw";
	}

	// 마이페이지 -> 사업자 상품등록페이지 불러오기
	@RequestMapping(value = "seller/goodsRegister", method = RequestMethod.GET)
	public String sellerRegisterGoods() {

		log.info("사업자 상품등록페이지 호출 성공");
		return "/goods/goodsRegiste";
	}

	// 마이페이지 -> 사업자 상품관리 목록 구현 12월21일 통합할때 추가
	@RequestMapping(value = "seller/manageGoods", method = RequestMethod.GET)
	public String goodsList(@ModelAttribute GoodsVO gvo, Model model, HttpSession session) {

		log.info("goodsList 호출 성공");

		// 로그인에서 설정한 세션값 가져오기
		SellerJoinVO login = (SellerJoinVO) session.getAttribute("loginSession");

		// 메소드에 들어갈 파라미터 svo에 세션에서 설정한 s_email을 set함
		gvo.setS_email(login.getS_email());

		// 페이지 세팅
		Paging.setPage(gvo);

		// 전체 레코드수 구현
		int total = goodsService.goodsListCnt(gvo);

		log.info("상품 total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(gvo.getPage()) - 1) * Util.nvl(gvo.getPageSize());

		// goodsList 변수를 선언하고 goodsService 내 goodsList메소드 호출하여 변수에 저장
		List<GoodsVO> goodsList = goodsService.mypageGoodsList(gvo);

		// 모델에 추가
		model.addAttribute("goodsList", goodsList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", gvo);

		System.out.println("s_email :" + gvo.getS_email());

		return "mypage/seller/manageGoods";
	}

	// 마이페이지 -> 사업자 예약관리 목록 구현 12월21일 통합할때 추가
	@RequestMapping(value = "seller/reservationManage", method = RequestMethod.GET)
	public String reservationList(@ModelAttribute ReservationVO rvo, Model model, HttpSession session) {

		log.info("reservationList 호출 성공");

		// 로그인에서 설정한 세션값 가져오기
		SellerJoinVO login = (SellerJoinVO) session.getAttribute("loginSession");

		// 메소드에 들어갈 파라미터 svo에 세션에서 설정한 s_email을 set함
		rvo.setS_email(login.getS_email());

		// 페이지 세팅
		Paging.setPage(rvo);

		// 전체 레코드수 구현
		int total = sellerReservationService.sellerReservationCnt(rvo);

		log.info("예약 total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(rvo.getPage()) - 1) * Util.nvl(rvo.getPageSize());

		// bookList 변수를 선언하고 bookService 내 bookList메소드 호출하여 변수에 저장
		List<ReservationVO> reservationList = sellerReservationService.sellerReservationList(rvo);

		// 모델에 추가
		model.addAttribute("reservationList", reservationList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", rvo);

		System.out.println("s_email :" + rvo.getS_email());
		return "mypage/seller/reservationManage";
	}

	// 마이페이지 -> 사업자 매출현황페이지 불러오기
	@RequestMapping(value = "seller/salesPresent", method = RequestMethod.GET)
	public String sellerSalesPresent(@ModelAttribute SellerSalesVO svo, Model model, HttpSession session) {

		log.info("사업자 매출현황 페이지 호출 성공");

		// 로그인에서 설정한 세션값 가져오기
		SellerJoinVO login = (SellerJoinVO) session.getAttribute("loginSession");

		// 메소드에 들어갈 파라미터 svo에 세션에서 설정한 s_email을 set함
		svo.setS_email(login.getS_email());

		// 페이지 세팅
		Paging.setPage(svo);

		// 전체 레코드수 구현
		int total = sellerSalesService.sellerSalesCnt(svo);

		log.info("등록한 상품 total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(svo.getPage()) - 1) * Util.nvl(svo.getPageSize());

		// bookList 변수를 선언하고 bookService 내 bookList메소드 호출하여 변수에 저장
		List<SellerSalesVO> sellerSalesList = sellerSalesService.sellerSalesList(svo);

		// 사업자가 등록한 모든 상품 총매출
		String sellerSalesTotal = sellerSalesService.sellerSalesTotal(svo);
		
				

		// 모델에 추가
		model.addAttribute("sellerSalesList", sellerSalesList);
		model.addAttribute("sellerSalesTotal", sellerSalesTotal);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", svo);

		// System.out.println("s_email :" + svo.getS_email());
		return "mypage/seller/salesPresent";
	}

	// 마이페이지 -> 사업자 회원탈퇴 페이지 불러오기
	@RequestMapping(value = "seller/sellerRetire", method = RequestMethod.GET)
	public String sellerRetire(@ModelAttribute("SellerJoinVO") SellerJoinVO svo, HttpSession session) {
		return "mypage/seller/sellerRetire";
	}

	// 마이페이지 -> 사업자 회원탈퇴 페이지 불러오기
	@RequestMapping(value = "user/userRetire", method = RequestMethod.GET)
	public String userRetire(@ModelAttribute("UserJoinVO") UserJoinVO uvo, HttpSession session) {
		return "mypage/user/userRetire";
	}

	// 마이페이지 -> 사업자 회원탈퇴
	@RequestMapping(value = "seller/deleteSuc", method = RequestMethod.POST)
	public ModelAndView sellerDelete(@ModelAttribute("SellerJoinVO") SellerJoinVO svo, HttpSession session) {

		ModelAndView mav = new ModelAndView();
		int result = 0;
		SellerJoinVO sVo = loginService.sellerlogin(svo);
		if (sVo != null) {
			if (BCrypt.checkpw(svo.getS_pw(), sVo.getS_pw())) {
				result = managerSellerService.sellerWithdrawal(svo.getS_email());
				if (result == 1) {
					session.invalidate();
					mav.addObject("code", 1);
					mav.setViewName("/mypage/seller/deleteSuc");
				} else if (result == 2) {
					mav.addObject("code", 2);
					mav.setViewName("/mypage/seller/deleteSuc");
				} else if (result == 3) {
					mav.addObject("code", 3);
					mav.setViewName("/mypage/seller/deleteSuc");
				}
			} else {
				mav.addObject("code", 0);
				mav.setViewName("/mypage/seller/deleteSuc");
			}
		}
		return mav;
	}

	// 마이페이지 -> 사용자 회원탈퇴
	@RequestMapping(value = "user/deleteSuc", method = RequestMethod.POST)
	public ModelAndView userDelete(@ModelAttribute("UserJoinVO") UserJoinVO uvo, HttpSession session) {

		ModelAndView mav = new ModelAndView();
		int result = 0;
		UserJoinVO uVo = loginService.userlogin(uvo);
		if (uVo != null) {
			if (BCrypt.checkpw(uvo.getU_pw(), uVo.getU_pw())) {
				result = managerUserService.userWithdrawal(uvo.getU_email());
				if (result == 1) {
					session.invalidate();
					mav.addObject("code", 1);
					mav.setViewName("/mypage/user/deleteSuc");
				} else {
					mav.addObject("code", 2);
					mav.setViewName("/mypage/user/deleteSuc");
				}
			} else {
				mav.addObject("code", 0);
				mav.setViewName("/mypage/user/deleteSuc");
			}
		}
		return mav;
	}

}

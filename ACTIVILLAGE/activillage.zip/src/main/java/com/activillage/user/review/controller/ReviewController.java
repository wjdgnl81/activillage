package com.activillage.user.review.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.user.book.service.BookService;
import com.activillage.user.book.vo.BookVO;
import com.activillage.user.review.service.ReviewService;
import com.activillage.user.review.vo.ReviewVO;

@Controller
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private ReviewService reviewService;

	/* ---------------12.28변경 */
	// 리뷰쓰기 제한 두기
	@Autowired
	private BookService bookService;

	// 리뷰 목록
	/*@RequestMapping(value = "/reviewRead.do", method = RequestMethod.GET)
	public ModelAndView reviewList(@RequestParam ReviewVO rvo, int g_no, ModelAndView mav, HttpSession session) {
		System.out.println("reviewList 호출성공");

		// 12-31페이징
		rvo.setPageSize(3 + "");
		Paging.setPage(rvo);
		System.out.println(rvo.getPageSize());
		// 리뷰 전체 레코드 수 구현
		int total = reviewService.reviewListCnt(rvo);
		System.out.println("리뷰 total = " + total);
		// 리뷰 번호 재설정
		int count = total - (Util.nvl(rvo.getPage()) - 1) * Util.nvl(rvo.getPageSize());
		
		
		List<ReviewVO> reviewList = reviewService.reviewList(g_no);
		System.out.println(reviewList.get(0).getG_no());
		 mav.setViewName("goods/reviewRead"); 
		mav.addObject("reviewList", reviewList);
		
		//12-31페이징
		mav.addObject("count", count);
		mav.addObject("total", total);
		mav.addObject("data", rvo);
		return mav;
	}*/

	// 리뷰 입력
	@ResponseBody
	@RequestMapping(value = "/reviewWriteForm.do", method = RequestMethod.POST)
	public String reviewWrite(@ModelAttribute ReviewVO rvo, HttpSession session) {

		System.out.println("reviewWrite 호출성공");
		int result = 0;
		System.out.println(rvo.getG_no());
		reviewService.reviewWrite(rvo);
		ReviewVO review = reviewService.gradeSelect(rvo);
		System.out.println(review.getR_grade());
		reviewService.grageUpdate(review);
		result = 1;

		return result + "";
	}

	// 리뷰 삭제
	@ResponseBody
	@RequestMapping(value = "/reviewDelete.do", method = RequestMethod.POST)
	public String reviewDelete(@ModelAttribute ReviewVO rvo, HttpSession session) throws IOException {
		System.out.println("reviewDelete 호출 성공");
		int result = 0;
		result = reviewService.reviewDelete(rvo.getR_no());
		if (reviewService.gradeSelect(rvo) != null) {
			ReviewVO review = reviewService.gradeSelect(rvo);
			System.out.println(review.getR_grade());
			reviewService.grageUpdate(review);
		} else {
			System.out.println("리뷰없음");
			System.out.println(rvo.getG_no());
			rvo.setR_grade(0);
			reviewService.grageUpdate(rvo);
		}
		System.out.println("리뷰삭제 결과 : " + result);
		return result + "";
	}

	/* ---------------12.28변경 */
	// 리뷰쓰기 제한 두기
	@ResponseBody
	@RequestMapping(value = "/goReviewWrite.do", method = RequestMethod.POST)
	public String goReviewWrite(@ModelAttribute BookVO bvo, HttpSession session) throws IOException {
		System.out.println("goReviewWrite 호출 성공");
		int result = 0;
		String blank = "";
		if (bvo.getU_email() == null || bvo.getU_email().equals("")) {
			bvo.setU_email(blank);
		}
		System.out.println(bvo.getU_email() + "이메일");
		System.out.println(bvo.getG_name() + "상품명");

		if (bookService.goReviewWrite(bvo) == 1) {
			result = 1;
		} else {
			result = 0;
		}
		System.out.println("리뷰작성 결과 : " + result);
		return result + "";
	}
}

package com.activillage.user.book.vo;

import com.activillage.common.vo.CommonVO;

public class BookVO extends CommonVO{
	public int b_no = 0; // 예약 고유번호
	public String u_email = ""; // 사용자 이메일
	public int p_no = 0; // 패키지 고유번호
	public String u_name = ""; // 사용자 이름
	public String p_name = ""; // 패키지명
	public String g_name = ""; // 상품명
	public String b_bday = ""; // 예약일
	public String b_pday = ""; // 결제일
	public String b_cday = ""; // 취소일
	public int b_tprice = 0; // 총 가격
	public int b_tamount = 0; // 총 수량
	
	public int book_count = 0; //예약 수
	
	

	public int getBook_count() {
		return book_count;
	}

	public void setBook_count(int book_count) {
		this.book_count = book_count;
	}

	public int getB_no() {
		return b_no;
	}

	public void setB_no(int b_no) {
		this.b_no = b_no;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public int getP_no() {
		return p_no;
	}

	public void setP_no(int p_no) {
		this.p_no = p_no;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getB_bday() {
		return b_bday;
	}

	public void setB_bday(String b_bday) {
		this.b_bday = b_bday;
	}

	public String getB_pday() {
		return b_pday;
	}

	public void setB_pday(String b_pday) {
		this.b_pday = b_pday;
	}

	public String getB_cday() {
		return b_cday;
	}

	public void setB_cday(String b_cday) {
		this.b_cday = b_cday;
	}

	public int getB_tprice() {
		return b_tprice;
	}

	public void setB_tprice(int b_tprice) {
		this.b_tprice = b_tprice;
	}

	public int getB_tamount() {
		return b_tamount;
	}

	public void setB_tamount(int b_tamount) {
		this.b_tamount = b_tamount;
	}

}

package com.activillage.user.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.notice.vo.NoticeVO;

@Repository
public class NoticeDaoImpl implements NoticeDao {

	@Autowired
	private SqlSession session;

	// 목록보기
	@Override
	public List<NoticeVO> noticeList() {
		return session.selectList("noticeList");
	}

	// 등록하기
	@Override
	public int noticeRegi(NoticeVO nvo) {
		return session.insert("noticeRegi", nvo);
	}

	@Override
	public NoticeVO noticeDetail(NoticeVO nvo) {
		return (NoticeVO) session.selectOne("noticeDetail", nvo);
	}

	@Override
	public int noticeUpdate(NoticeVO nvo) {
		return session.update("noticeUpdate", nvo);
	}

	@Override
	public int noticeDelete(int n_no) {
		return session.delete("noticeDelete", n_no);
	}

}

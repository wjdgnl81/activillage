package com.activillage.user.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.book.dao.BookDao;
import com.activillage.user.book.vo.BookVO;

@Service
@Transactional
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;

	@Qualifier("bookDao")

	// 카드결제
	@Override
	public int cardPay(BookVO bvo) {

		int result = 0;

		try {
			result = bookDao.cardPay(bvo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	// 예약 수 불러오기
	@Override
	public BookVO bookCount(BookVO bvo) {

		BookVO bookCount = null;
		bookCount = bookDao.bookCount(bvo);

		return bookCount;
	}

	// 2018-12-21 추가 - 김정휘
	// 상품명으로 예약 존재하는지 체크
	@Override
	public int bookCheck(String g_name) {

		int result;
		List<BookVO> re = bookDao.bookCheck(g_name);

		if (re.size() != 0) {
			result = 1;
		} else {
			result = 2;
		}

		return result;
	}

	@Override
	public int bookCheck2(int p_no) {

		int result;
		List<BookVO> re = bookDao.bookCheck2(p_no);

		if (re.size() != 0) {
			result = 1;
		} else {
			result = 2;
		}

		return result;
	}

	@Override
	public int goReviewWrite(BookVO bvo) {
		int goReviewWrite = 0;
		try {
			if (bookDao.goReviewWrite(bvo).isEmpty()) {
				goReviewWrite = 0;
			} else {
				goReviewWrite = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			goReviewWrite = 0;
		}
		return goReviewWrite;
	}

	@Override
	public int userReservationCnt(BookVO bvo) {
		return bookDao.userReservationCnt(bvo);
	}

	@Override
	public List<BookVO> userReservationList(BookVO bvo) {
		List<BookVO> userReservationList = null;

		userReservationList = bookDao.userReservationList(bvo);

		return userReservationList;
	}

	@Override
	public int bookCancle(BookVO bvo) {
		int result = 0;
		try {
			result = bookDao.bookCancle(bvo);

		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

}

package com.activillage.user.ganswer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.user.ganswer.dao.GanswerDAOImpl;
import com.activillage.user.ganswer.vo.GanswerVO;

@Service
@Transactional
public class GanswerServiceImpl implements GanswerService {

	@Autowired
	private GanswerDAOImpl gAnswerDAOImpl;

	public List<GanswerVO> gAnswerList(int g_q_no) {
		return gAnswerDAOImpl.gAnswerList(g_q_no);
	}

	public void gAnswerWrite(GanswerVO avo) {
		gAnswerDAOImpl.gAnswerWrite(avo);

	}

	public int gAnswerDelete(int g_q_no) {
		int result = 0;
		try {
			result = gAnswerDAOImpl.gAnswerDelete(g_q_no);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

}

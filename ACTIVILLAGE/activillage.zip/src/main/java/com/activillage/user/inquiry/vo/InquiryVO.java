package com.activillage.user.inquiry.vo;

import com.activillage.common.vo.CommonVO;

public class InquiryVO extends CommonVO {
	private int s_q_no; // 사이트문의 고유번호
	private String u_email; // 사용자 이메일(FK)
	private String s_q_title; // 문의 제목
	private String s_q_content; // 문의 내용
	private String s_q_date; // 작성 날짜

	public int getS_q_no() {
		return s_q_no;
	}

	public void setS_q_no(int s_q_no) {
		
		this.s_q_no = s_q_no;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public String getS_q_title() {
		return s_q_title;
	}

	public void setS_q_title(String s_q_title) {
		this.s_q_title = s_q_title;
	}

	public String getS_q_content() {
		return s_q_content;
	}

	public void setS_q_content(String s_q_content) {
		this.s_q_content = s_q_content;
	}

	public String getS_q_date() {
		return s_q_date;
	}

	public void setS_q_date(String s_q_date) {
		this.s_q_date = s_q_date;
	}
}

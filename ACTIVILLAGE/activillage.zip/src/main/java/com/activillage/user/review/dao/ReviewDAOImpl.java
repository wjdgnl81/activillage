package com.activillage.user.review.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.user.review.vo.ReviewVO;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Autowired
	private SqlSession session;

	@Override
	public void reviewWrite(ReviewVO rvo) {

		session.insert("com.activillage.user.review.dao.ReviewDAO.reviewInsert", rvo);
	}

	@Override
	public List<ReviewVO> reviewList(ReviewVO rvo) {
		return session.selectList("reviewList", rvo);
	}

	@Override
	public void grageUpdate(ReviewVO rvo) {
		session.update("grageUpdate", rvo);

	}

	@Override
	public ReviewVO gradeSelect(ReviewVO rvo) {
		return session.selectOne("gradeSelect", rvo);
	}
	
	@Override
	public int reviewDelete(int r_no) {
		return session.delete("reviewDelete", r_no);
	}
	
	@Override
	public int reviewListCnt(ReviewVO rvo) {
		return (Integer) session.selectOne("reviewListCnt");
	}

}
